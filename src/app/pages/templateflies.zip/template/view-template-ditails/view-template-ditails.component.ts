// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-view-template-ditails',
//   templateUrl: './view-template-ditails.component.html',
//   styleUrls: ['./view-template-ditails.component.scss']
// })
// export class ViewTemplateDitailsComponent {

// }


import { Component, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzCarouselComponent } from 'ng-zorro-antd/carousel';
import { ReportService } from 'src/app/service/report.service';
import { TemplateMessageService } from 'src/app/service/template-message.service';
import { TemplateService } from 'src/app/service/template-service.service';
import { ToastService } from 'src/app/shared/toast-service.service';

@Component({
    selector: 'app-view-template-ditails',
    templateUrl: './view-template-ditails.component.html',
    styleUrls: ['./view-template-ditails.component.scss']
  })
export class ViewTemplateDitailsComponent {

selectedtemplate:any
templateId: any;
newTemplate: any;
messageTemplates:any[]=[];
   @ViewChild('carouselRef', { static: false }) carousel!: NzCarouselComponent;
    cards: { id: number; previewUrl: string | null }[] = [
    
    ];
    addPage:boolean=true
    ViewPage:boolean=false
    imageHeight = 120;
    orientation = 'vertical';
    selectedCardIndex: number | null = null;
    templateType: string = 'rich_card'; 
    templateForm!: FormGroup;
    cardTitle: string = '';
    carouselList:{ cardTitle: string;cardDescription:string; fileName:string | null; suggestions:[] }[] =[
      {  cardTitle: '', cardDescription: '',  fileName:"",suggestions:[]},
      {  cardTitle: '', cardDescription: '', fileName:"",suggestions:[] },
    ];
    carouseldetails:{ cardTitle: string;}[] =[
      
    ];
    // suggestions: FormArray = this.fb.array([]);
    type: string = '';
    text: string = '';
    postback: string = '';
    currentStep: number = 1;
    // isFallbackEnabled: boolean = false;
    messageBody: boolean = true;
    TextMessage: boolean = true;
    fallbackSmsContent: string = ''; 
    carddescription: string = '';
    Suggestiontext: string = '';
    messagecontent: string = '';
    previewUrl: string | null = null;
    uploadedFileSize: string | null = null;
    uploadedFileUrl: string | null = null;
    newbot: any;
    edit:boolean=false
    valueChangesSubscription: any; 
//isFallbackEnabled: any;



prevSlide(): void {
  this.carousel.pre();
}

nextSlide(): void {

  this.carousel.next();

}
addTepmlate()
{
this.addPage=true

}

viewTemplate(){
this.ViewPage=true
}
selectCard(index: number) {
this.selectedCardIndex = this.selectedCardIndex === index ? null : index; 

this.carousel.goTo(index)
console.log(this.carouselList[index])

// const cardDes = this.carouselList[index].cardDescription
//const cardTitle = this.carouselList[index].cardTitle


this.updateValue(index)


}
updateValue(i:number){
    
  // this.templateForm.get('cardTitle')?.valueChanges.subscribe(value => {
  //   this.carouselList[i].cardTitle = value;
  // });
  // this.cardTitle=this.carouselList[i].cardTitle
  
  // this.templateForm.patchValue({
  //   cardTitle:this.cardTitle
  // })

  const selectedCard = this.carouselList[i];

  // Set form values to selected card data
  this.templateForm.patchValue({
    cardTitle: selectedCard.cardTitle,
    cardDescription: selectedCard.cardDescription,
    
  });

  // Unsubscribe previous subscription before creating a new one
  if (this.valueChangesSubscription) {
    this.valueChangesSubscription.unsubscribe();
  }
  // Subscribe to valueChanges and update the corresponding card dynamically
  // this.valueChangesSubscription = this.templateForm.valueChanges.subscribe(values => {
  //   if (this.selectedCardIndex !== null) {
  //     this.carouselList[this.selectedCardIndex].cardTitle =this.cardTitle
  //     this.carouselList[this.selectedCardIndex].cardDescription = this.carddescription
      
   // }
  //});
}
addCard() {
if (this.carouselList.length < 10) {
  //this.cards.push({ id: this.cards.length + 1, previewUrl: null });
  this.carouselList.push({
  cardTitle:"",
  cardDescription:"",
  fileName:"",
  suggestions:[]
  })
  
}
}

deleteCard(index: number) {
this.cards.splice(index, 1);
this.carouselList.splice(index,1)
}
constructor(private reportService: ReportService,private templateMessageService:TemplateMessageService,private fb: FormBuilder, private toastService: ToastService, private templateService: TemplateService,){

  this.templateForm = this.fb.group({
      botid:[{value:'', disabled:'true'}],
      type: [{value:this.templateType, disabled:'true'}],
      name: [{value:'', disabled:'true'}],
      fallbackText: [{value:'', disabled:'true'}],
      height:[{value:'', disabled:'true'}],
      width:[{value:'', disabled:'true'}],
      // fileName: [''],
      cardTitle: [{value:this.cardTitle, disabled:'true'}],
      messagecontent:[{value:'', disabled:'true'}],
      cardOrientation:[{value:'', disabled:'true'}],
      cardDescription: [{value:'', disabled:'true'}],
      standAloneFileName: [{value:'', disabled:'true'}],
      thumbnailFileName: [{value:'', disabled:'true'}],
      selectcardallignment:[{value:'', disabled:'true'}],
      //fallback: ['no', Validators.required],
      suggestions: this.fb.array([])
    });
}
ngOnInit(){
  const selectedtemplate = this.templateMessageService.getTemplateDetails();
  if (selectedtemplate ) { 
    console.log('Bot details on bot creation page:',selectedtemplate );
    this.edit=true;
    let data = {
      loggedInUserName: sessionStorage.getItem('USER_NAME'),
      templateName :selectedtemplate
    };

    this.templateService.templateDetail(data).subscribe(
      (res) => {
        if (res) {
          console.log(res.botId)
          // Initialize form with values
          if(res.type=='rich_card')
          this.templateForm.patchValue({
            botid:res.botId,
            type: res.type,
            name: res.name,
            fallbackText: res.fallbackText,
            height: res.height,
            width: res.width,
            cardTitle: res.standAlone.cardTitle,
            messagecontent: res.textMessageContent,
            cardOrientation: res.cardOrientation,
            cardDescription: res.standAlone.cardDescription,
            standAloneFileName: res.standAlone.fileName,
            thumbnailFileName: res.standAlone.thumbnailFileName,
            //fallback: ['no', Validators.required],
            suggestions: res.standAlone.suggestionTypeRich.map((s:any)=>{
              type:s.suggestionType
              text:s.displayText
              postback:s.postback
            })
          });
          else if (res.type=='carousel'){
              console.log("carousel")
              console.log("carousel length:" ,res.carouselList)
              this.carouselList=res.carouselList
              this.templateForm.patchValue({
                type: res.type,
                name: res.name,
                fallbackText: res.fallbackText,
                height: res.height,
                width: res.width,
                //cardTitle: res.carouselList.cardTitle,
                messagecontent: res.textMessageContent,
                cardOrientation: res.cardOrientation,
                //cardDescription: res.carouselList.cardDescription,

              })
          }

          // console.log('Form patched successfully:', this.templateForm.value);
        } else {
          console.error('Invalid API response:', res);
        }
      },
      (error) => {
        console.error('Failed to fetch bot details:', error);
      }
    );
  } else {
    console.error('No bot details found.');
  }
  this.messageTemplates =[]
        let dt = {
          "loggedInUserName":sessionStorage.getItem('USER_NAME'),
       }
       this.reportService.templatelist(dt).subscribe((res: any) => {
         console.log(res);
         if (res.data && res.data.templateList) {
           this.messageTemplates = res.data.templateList; 
         } else {
           this.messageTemplates = []; 
         }
       });


       
}

get suggestions() {
    return this.templateForm.get('suggestions') as FormArray;
  }

  // Getter for fallback enabled
  get isFallbackEnabled() {
    return this.templateForm.get('fallback')?.value === 'yes';
  }

  // Add suggestion
  addSuggestion(): void {
    this.suggestions.push(
      this.fb.group({
        type: ['Reply', Validators.required],
        text: ['', [Validators.required, Validators.maxLength(25)]],
        postback: ['', [Validators.required, Validators.maxLength(120)]]
      })
    );
  }

  // Remove suggestion
  removeSuggestion(index: number): void {
    this.suggestions.removeAt(index);
  }
  
  // Transform suggestions to API format
  transformSuggestions(suggestions: any[]): any[] {
    return suggestions.map(suggestion => {
      switch (suggestion.type) {
        case 'urlaction':
          return {
            suggestionType: 'url_action',
            url: suggestion.text,
            displayText: suggestion.postback,
            postback: suggestion.postback
          };
        case 'dialer':
          return {
            suggestionType: 'dialer_action',
            phoneNumber: suggestion.text,
            displayText: suggestion.postback,
            postback: suggestion.postback
          };
        case 'Reply':
          return {
            suggestionType: 'reply',
            displayText: suggestion.text,
            postback: suggestion.postback
          };
        // Add other cases for different suggestion types
        default:
          return {
            suggestionType: suggestion.type,
            displayText: suggestion.text,
            postback: suggestion.postback
          };
      }
    });
    
   
    

  
    

    
    // messageBody
   
  }





  ontypeChange(value: string): void {
    console.log('Selected Template Type:', value);
    if (value === 'TextMessage') {
      this.templateForm.patchValue({
        cardOrientation: '',
        height: '',
        imagevideo: '',
        cardTitle: '',
        cardDescription: ''
      });
    }
  }

  onFileChange(event: any): void {
    const file = event.file.originFileObj;
    const reader = new FileReader();
    reader.onload = () => {
      this.previewUrl = reader.result as string;
    };
    reader.readAsDataURL(file);
  }

  handlePreview = (file: any): Promise<string> => {
    return Promise.resolve(file.url || file.thumbUrl);
  };


  



  uploadImage(event: any, cardIndex: number) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.cards[cardIndex].previewUrl = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }




  
    formatMessageBody(text: string, limit: number = 26): string[] {
      if (!text) return [];
      
      // Split text into chunks of 'limit' characters, without breaking words
      const result: string[] = [];
      let index = 0;
      
      // Continue until all characters are processed
      while (index < text.length) {
        // Slice the string from the current index to the next 'limit' number of characters
        result.push(text.slice(index, index + limit));
        index += limit;
      }
      
      return result;
    }

    onOrientationChange(selectedOrientation: string): void {
      this.orientation = selectedOrientation;
    }

    navigateLeft() {
      const carousel = document.querySelector('.ant-carousel .slick-prev') as HTMLElement;
      if (carousel) carousel.click();
    }

    onHeightChange(selectedHeight: string): void {
      if (selectedHeight === 'SHORT_HEIGHT') {
        this.imageHeight = 100; // Reset to default or desired "SHORT" height
      } else if (selectedHeight === 'MEDIUM_HEIGHT') {
        this.imageHeight = 140; // Increase by 10px for "MEDIUM" height
      }
    }
  
    navigateRight() {
      const carousel = document.querySelector('.ant-carousel .slick-next') as HTMLElement;
      if (carousel) carousel.click();
    }
    
    
    

  beforeUpload = (file: File): boolean => {
    // Validate file type or size if needed
    this.templateForm.patchValue({ pdfFile: file });
    this.uploadedFileSize = file.name;
    return false;
  };

  // handleFileChange(event: any): void {
  //   // Handle any file change logic if required
  //   console.log('File uploaded:', event.file);
  // }

  handleFileChange(event: any): void {
    const file = event.file?.originFileObj;
    if (file) {
      this.uploadedFileSize = file.name;
      this.uploadedFileUrl = 'URL_TO_DOWNLOADED_FILE'; // Set dynamically
      this.uploadedFileSize = (file.size / 1024).toFixed(2) + ' KB'; // Convert size to KB
    }
  }
  onSubmit() {
    console.log("Form submitted"); // Check if function is triggered
  
    // if (!this.templateForm.valid) {
    //   console.error("Form validation failed:", this.templateForm.errors);
    //   console.log("Form controls status:", this.templateForm.controls);
    //   return; // Stop execution if form is invalid
    // }
  
    const formData = this.templateForm.value;
    console.log("Form data:", formData); // Log the entire form data
  
    let dt: any; // Declare dt once
  
    if (formData.type === 'rich_card') {
      console.log("Rich card condition met"); // Debug lo
      dt = {
        loggedInUserName: sessionStorage.getItem('USER_NAME'),
        botId:formData.botid,
        richTemplateData: {
          name: formData.name,
          fallbackText: formData.fallbackText,
          type: "rich_card",
          height: formData.height,
          width: formData.width,
          fileName: formData.fileName,
          standAlone: {
            cardTitle: formData.cardTitle,
            cardDescription: formData.cardDescription,
            fileName: formData.standAloneFileName,
            thumbnailFileName: formData.thumbnailFileName,
            suggestions: this.transformSuggestions(formData.suggestions)
          }
        }
      };
    } 
    else if (formData.type === 'TextMessage') {
      console.log("TextMessage condition met"); // Debug log
      dt = {
        loggedInUserName: sessionStorage.getItem('USER_NAME'),
        botId:formData.botid,
        richTemplateData: {
          name: formData.name,
          fallbackText: formData.fallbackText,
          type: "text_message",
          templateUseCase: "promo",
          height: formData.height,
          width: formData.width,
          textMessageContent: formData.messagecontent ?? '', // Default to empty string if undefined
          suggestions: this.transformSuggestions(formData.suggestions)
        }
      };
    } else {
      console.error("Invalid type:", formData.type); // Debug log for unexpected type
    }
  
    console.log("Final dt object:", dt); // Log final API payload before sending request

    if(dt && this.edit===true){
      this.templateService.editTemplate(dt).subscribe({
        next: (res: any) => {
          console.log('API Response:', res);
          if (res.result?.toLowerCase() === 'success' && res.data) {
            window.location.reload(); 
            this.toastService.publishNotification('success', res.message, 'success');
          } else {
            console.warn('Unexpected API response:', res);
          }
        },
        error: (error) => {
          console.error('Error adding template:', error);
          this.toastService.publishNotification('error', 'Failed to add template', 'error');
        }
      });
    }
    else {
      console.error("dt is undefined, API call not made"); // Log if dt is empty
      this.toastService.publishNotification('error', 'Invalid template data', 'error');
    }
  }

  getTemplateDetails(selectedtemplate:any)
  {
    // if (selectedtemplate ) { 
    //   console.log('Bot details on bot creation page:',selectedtemplate );
    //   this.edit=true;
    //   let data = {
    //     loggedInUserName: sessionStorage.getItem('USER_NAME'),
    //     templateName :selectedtemplate
    //   };
  
    //   this.templateService.templateDetail(data).subscribe(
    //     (res) => {
    //       if (res) {

    //         // Initialize form with values
    //         this.templateForm.patchValue({
    //           botid:res.botId,
    //           type: res.type,
    //           name: res.name,
    //           fallbackText: res.fallbackText,
    //           height: res.height,
    //           width: res.width,
    //           cardTitle: res.standAlone.cardTitle,
    //           messagecontent: res.textMessageContent,
    //           cardOrientation: res.cardOrientation,
    //           cardDescription: res.standAlone.cardDescription,
    //           standAloneFileName: res.standAlone.fileName,
    //           thumbnailFileName: res.standAlone.thumbnailFileName,
    //           //fallback: ['no', Validators.required],
    //           suggestions: res.standAlone.suggestionTypeRich.map((s:any)=>{
    //             type:s.suggestionType
    //             text:s.displayText
    //             postback:s.postback
    //           })
    //         });
  
    //         // console.log('Form patched successfully:', this.templateForm.value);
    //       } else {
    //         console.error('Invalid API response:', res);
    //       }
    //     },
    //     (error) => {
    //       console.error('Failed to fetch bot details:', error);
    //     }
    //   );
    // } else {
    //   console.error('No bot details found.');
    // }
  }
  
}

